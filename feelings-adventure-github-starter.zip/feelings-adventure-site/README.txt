FEELINGS ADVENTURE – GITHUB PAGES STARTER

FILES
- index.html: complete responsive learning website
- assets/welcome-art.jpg: cropped artwork from your supplied reference image
- assets/adventure-friends.jpg: cropped artwork from your supplied reference image

PUBLISH ON GITHUB
1. Create a new GitHub repository (for example: feelings-adventure).
2. Upload index.html and the whole assets folder. Keep the folder name exactly "assets".
3. Open the repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select the main branch and /(root), then Save.
6. Wait for GitHub Pages to publish the site. Open the URL shown in Settings > Pages.

INSERT YOUR CONTENT
- Video: search in index.html for "VIDEO EMBED SLOT". Replace the placeholder with the YouTube iframe embed code. Use the URL format https://www.youtube.com/embed/VIDEO_ID.
- Learning notes: search for "NOTES EMBED SLOT". Paste your Google Slides, Genially, PDF viewer or other embed code.
- Drilling: search for "DRILLING EMBED SLOT" and paste the relevant Year 1, Year 2 or Year 3 activity embed code.
- Games: search for "GAME EMBED SLOT" and paste the matching game's iframe code.
- Answer checking: search for "ANSWER CHECKING EMBED SLOT" and paste your quiz/answer-checking iframe code.
- AI Buddy: search for "AI INTEGRATION SLOT". Paste the Botpress Webchat integration code from your Botpress workspace. The current popup is a visual demo helper, not a connected AI chatbot.
- Music: place your MP3 at assets/background-music.mp3, then in index.html remove the HTML comment markers around the <source> line. Browsers generally require a user click before music can play.

EMBED EXAMPLE
<iframe src="https://www.youtube.com/embed/VIDEO_ID" width="100%" height="315"
  style="border:0;border-radius:16px" allowfullscreen loading="lazy"></iframe>

NOTES
- Keep external services' sharing/privacy settings configured so pupils can access the embedded activity.
- Some sites block iframe embedding. If an embed does not display, check that platform's embed/share settings or use its allowed embed link.
- The AI Buddy panel currently uses simple sample replies. A real AI response requires connecting Botpress or another AI service.
- The Year 1–3 vocabulary progression follows the supplied project documents. Check the official English DSKP before presenting the progression as official standards mapping.
